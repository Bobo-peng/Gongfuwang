function [xa]=nan(x)

 xa=[];
 for i=1:length(x)
    if ~isnan(x(i,1))
        xa=[xa;x(i,:)];
        
    end
end
